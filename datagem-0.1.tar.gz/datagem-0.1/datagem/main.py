#!/usr/bin/env python
# coding: utf-8

# In[2]:


get_ipython().system('pip install minio')


# In[ ]:


### Esta es la herramienta que he encontrado en Github para Read-Eval_Print_Loop (REPL) Codigo python. AST: AST significa "Abstract Syntax Tree", que es una 
## representación de árbol de la estructura sintáctica de un código fuente escrita en un lenguaje de programación. Python tiene un módulo llamado ast que permite 
## interactuar y manipular árboles de sintaxis abstracta. Este módulo es útil para analizar y modificar código Python de manera programática.

"""A tool for running python code in a REPL."""

import ast
import re
import sys
from contextlib import redirect_stdout
from io import StringIO
from typing import Any, Dict, Optional, Type

from langchain.pydantic_v1 import BaseModel, Field, root_validator
from langchain.tools.base import BaseTool
from langchain_core.callbacks.manager import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.runnables.config import run_in_executor

from langchain_experimental.utilities.python import PythonREPL

from time import sleep

# @note PythonREPLTool
def _get_default_python_repl() -> PythonREPL:
    return PythonREPL(_globals=globals(), _locals=None)


def sanitize_input(query: str) -> str:
    """Sanitize input to the python REPL.

    Remove whitespace, backtick & python (if llm mistakes python console as terminal)

    Args:
        query: The query to sanitize

    Returns:
        str: The sanitized query
    """

    # Removes `, whitespace & python from start
    query = re.sub(r"^(\s|`)*(?i:python)?\s*", "", query)
    # Removes whitespace & ` from end
    query = re.sub(r"(\s|`)*$", "", query)
    return query


class PythonREPLTool(BaseTool):
    """Tool for running python code in a REPL."""

    name: str = "Python_REPL"
    description: str = (
        "A Python shell. Use this to execute python commands. "
        "Input should be a valid python command. "
        "If you want to see the output of a value, you should print it out "
        "with `print(...)`."
    )
    python_repl: PythonREPL = Field(default_factory=_get_default_python_repl)
    sanitize_input: bool = True

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> Any:
        """Use the tool."""
        if self.sanitize_input:
            query = sanitize_input(query)
        return self.python_repl.run(query)

    async def _arun(
        self,
        query: str,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> Any:
        """Use the tool asynchronously."""
        if self.sanitize_input:
            query = sanitize_input(query)

        return await run_in_executor(None, self.run, query)


class PythonInputs(BaseModel):
    """Python inputs."""

    query: str = Field(description="code snippet to run")


class PythonAstREPLTool(BaseTool):
    """Tool for running python code in a REPL."""

    name: str = "python_repl_ast"
    description: str = (
        "A Python shell. Use this to execute python commands. "
        "Input should be a valid python command. "
        "When using this tool, sometimes output is abbreviated - "
        "make sure it does not look abbreviated before using it in your answer."
    )
    globals: Optional[Dict] = Field(default_factory=dict)
    locals: Optional[Dict] = Field(default_factory=dict)
    sanitize_input: bool = True
    args_schema: Type[BaseModel] = PythonInputs

    @root_validator(pre=True)
    def validate_python_version(cls, values: Dict) -> Dict:
        """Validate valid python version."""
        if sys.version_info < (3, 9):
            raise ValueError(
                "This tool relies on Python 3.9 or higher "
                "(as it uses new functionality in the `ast` module, "
                f"you have Python version: {sys.version}"
            )
        return values

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Use the tool."""
        try:
            if self.sanitize_input:
                query = sanitize_input(query)
            tree = ast.parse(query)
            module = ast.Module(tree.body[:-1], type_ignores=[])
            exec(ast.unparse(module), self.globals, self.locals)  # type: ignore
            module_end = ast.Module(tree.body[-1:], type_ignores=[])
            module_end_str = ast.unparse(module_end)  # type: ignore
            io_buffer = StringIO()
            try:
                with redirect_stdout(io_buffer):
                    ret = eval(module_end_str, self.globals, self.locals)
                    if ret is None:
                        return io_buffer.getvalue()
                    else:
                        return ret
            except Exception:
                with redirect_stdout(io_buffer):
                    exec(module_end_str, self.globals, self.locals)
                return io_buffer.getvalue()
        except Exception as e:
            return "{}: {}".format(type(e).__name__, str(e))

    async def _arun(
        self,
        query: str,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> Any:
        """Use the tool asynchronously."""

        return await run_in_executor(None, self._run, query)
        
## VERSION 7

## Eliminación de bucles.
import re
import pandas as pd
import traceback
from minio import Minio
from io import BytesIO
from langchain.llms import Ollama
import matplotlib.pyplot as plt
from difflib import get_close_matches
import statsmodels.api as sm
from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

# Configuración del modelo Ollama
ollama_model2 = Ollama(
    base_url="http://10.125.39.223:80",
    model="datagem:2b",
    #base_url="http://172.17.0.2:11434",
    #model="finetuned-gemma-2b-unsloth-q:1.5B",
    callback_manager=CallbackManager([StreamingStdOutCallbackHandler()]),
    temperature=0
)

# Cliente de MinIO
minio_client = Minio(
    "10.230.66.91:80",
    access_key="AN3UARVYOVY0UBLV",
    secret_key="PCTDCWCOMR1WGXYZCWAUK5MT5T03YKRV",
    secure=False
)

# Configuración inicial del Python REPL Tool
repl_tool = PythonREPLTool(globals=globals())


def ffo(user_input, df_columns, reformulation_prompt):
    reformulation_prompt = reformulation_prompt.format(user_input=user_input, df_columns=df_columns)
    try:
        response = ollama_model2.invoke(reformulation_prompt)
        python_code = response
        return python_code
    except Exception as e:
        print("Error durante la reformulación con Ollama:", e)
        return user_input

def read_csv_from_minio(bucket_name, file_name):
    try:
        response = minio_client.get_object(bucket_name, file_name)
        csv_data = response.read()
        df = pd.read_csv(BytesIO(csv_data))
        return df
    except Exception as e:
        print("Error al leer el archivo desde MinIO:", e)
        return pd.DataFrame()

# Función para encontrar el nombre de columna más similar
def find_closest_column(column_name, df_columns):
    closest_matches = get_close_matches(column_name, df_columns, n=1, cutoff=0.6)
    return closest_matches[0] if closest_matches else None

# Función para reemplazar nombres incorrectos de columnas basados en un error de columna inexistente
def replace_key_error_in_command(python_command, key_error, df_columns):
    closest_match = find_closest_column(key_error, df_columns)
    if closest_match:
        print(f"Reemplazando '{key_error}' por '{closest_match}' en el código.")
        python_command = python_command.replace(key_error, closest_match)
    else:
        print(f"No se pudo encontrar un reemplazo adecuado para '{key_error}'.")

    return python_command

# Función para reemplazar nombres incorrectos relacionados con ValueError
def replace_value_error_in_command(python_command, value_error, df_columns):
    closest_match = find_closest_column(value_error, df_columns)
    if closest_match:
        print(f"Reemplazando '{value_error}' por '{closest_match}' en el código.")
        python_command = python_command.replace(value_error, closest_match)
    else:
        print(f"No se pudo encontrar un reemplazo adecuado para '{value_error}'.")

    return python_command

# Función para corregir ValueError relacionado con la conversión de tipos
def fix_string_to_float_error(python_command, df_columns):
    categorical_columns = [col for col in df_columns if df[col].dtype == 'object']
    if categorical_columns:
        print(f"Detectadas columnas categóricas: {categorical_columns}")
        encoding_code = f"""
from sklearn.preprocessing import OneHotEncoder
encoder = OneHotEncoder(drop='first', sparse_output=False)
encoded_features = encoder.fit_transform(df[{categorical_columns}])
encoded_df = pd.DataFrame(encoded_features, columns=encoder.get_feature_names_out({categorical_columns}))
df = pd.concat([df, encoded_df], axis=1)
df.drop({categorical_columns}, axis=1, inplace=True)
"""
        python_command = encoding_code + '\n' + python_command
        print("Agregando codificación de columnas categóricas al comando.")
    else:
        print("No se detectaron columnas categóricas para codificar.")

    return python_command

def datagem(interfaz=True):
    if_minio = input("¿Quieres conectarte a Minio? (sí/no)").lower() == "sí"
    
    if if_minio:
        bucket_name = input("Nombre del bucket: ")
    
    csv_filename = input("Nombre del archivo: ")

    print("""

██████╗  █████╗ ████████╗ █████╗  ██████╗ ███████╗███╗   ███╗ █████╗ 
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝ ██╔════╝████╗ ████║██╔══██╗
██╔══██╝███████║   ██║   ███████║██║  ███╗█████╗  ██╔████╔██║███████║
██╔══██ ██╔══██║   ██║   ██╔══██║██║   ██║██╔══╝  ██║╚██╔╝██║██╔══██║
██████╗ ██║  ██║   ██║   ██║  ██║╚██████╔╝███████╗██║ ╚═╝ ██║██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝

¡Hola! Soy Datagema, tu asistente de codificación en Python para ciencia de datos.
Estoy aquí para ayudarte a iniciar la creación de código con tus datos, ya sea para
visualización, técnicas estadísticas o manipulación de tu DataFrame. 🚀 

El código generado se ejecuta sobre el dataframe que escojas pero lo más recomendable es que partas 
de él para implementarlo o modificarlo como desees.

¿Qué puedo hacer por ti hoy? Aquí algunas ideas:
- Visualizar de datos (por ejemplo, 'Genera un gráfico de violin de la columna X agrupado por Y').
- Filtrar los datos basados en una condición (por ejemplo, 'filtra donde columna X sea mayor que 5').
- Calcular estadísticas descriptivas (por ejemplo, 'describe la columna Y').

Escribe 'salir' cuando desees terminar la sesión.

¡Vamos a crear algo increíble juntos! 🎉
""")
    
    global df
    if if_minio:
        df = read_csv_from_minio(bucket_name, csv_filename)
    else:
        df = pd.read_csv(csv_filename)
    
    print(df.head())
    history = [df.copy()]
    df_columns = list(df.columns)

    repl_tool = PythonREPLTool(globals=globals())
    queries = []

    while True:
        user_input = input("Escribe aquí qué te gustaría hacer con el DataFrame.")
        if user_input.lower() == 'salir':
            print("Terminando la sesión con el agente. ¡Hasta pronto!")
            break
        elif user_input.lower() == "reinicia":
            pandogem_minio3(interfaz)
            break
        else:
            prompt = "Dado un dataframe 'df' con columnas {df_columns}. Escribe la siguiente instrucción en Python asegurando que los nombres de las columnas se correspondan: {user_input}"
            python_command = ffo(user_input, df_columns, reformulation_prompt=prompt)
            
            print("Comando original:", python_command)

           

            attempt = 0
            max_attempts = 5
            previous_errors = set()

            while attempt < max_attempts:
                try:
                    # Intentar ejecutar el comando generado
                    response = repl_tool._run(python_command)
                    print("Respuesta del Agente:", response)
                    if 'plt.show()' not in python_command:
                        exec(python_command + '\nplt.show()')
                    else:
                        exec(python_command)
                    break
                except KeyError as e:
                    key_error = str(e).strip("'")
                    print(f"KeyError detectado: {key_error}")
                    if key_error in previous_errors:
                        print(f"El KeyError '{key_error}' se repite. Deteniendo los intentos.")
                        break
                    previous_errors.add(key_error)
                    python_command = replace_key_error_in_command(python_command, key_error, df_columns)
                    print("Python command corregido:", python_command, sep="\n", end="\n\n")
                    attempt += 1
                except ValueError as e:
                    error_message = str(e)
                    if "Could not interpret value" in error_message:
                        value_error = error_message.split("`")[1]
                        print(f"ValueError detectado: {value_error}")
                        if value_error in previous_errors:
                            print(f"El ValueError '{value_error}' se repite. Deteniendo los intentos.")
                            break
                        previous_errors.add(value_error)
                        python_command = replace_value_error_in_command(python_command, value_error, df_columns)
                        print("Python command corregido:", python_command, sep="\n", end="\n\n")
                        attempt += 1
                    elif "could not convert string to float" in error_message:
                        print(f"ValueError detectado: {error_message}")
                        python_command = fix_string_to_float_error(python_command, df_columns)
                        print("Python command corregido:", python_command, sep="\n", end="\n\n")
                        attempt += 1
                    else:
                        print("Error al ejecutar el código:", e)
                        traceback.print_exc()
                        break
                except TypeError as e:
                    if "OneHotEncoder.__init__() got an unexpected keyword argument 'sparse'" in str(e):
                        print(f"TypeError detectado: {e}")
                        python_command = python_command.replace("sparse=", "sparse_output=")
                        print("Python command corregido:", python_command, sep="\n", end="\n\n")
                        attempt += 1
                    else:
                        print("Error al ejecutar el código:", e)
                        traceback.print_exc()
                        break
                
                except Exception as e:
                    print("Error al ejecutar el código:", e)
                    error_message = traceback.format_exc()
                    print(error_message)

                    retry = input("Parece que ha habido un error en mi generación de código. ¿Lo intento de nuevo? (sí/no)").lower() == "sí"
                    if retry:
                        additional_guidance = input("¿Qué podría corregir?")
                        if additional_guidance.lower() == 'rag':
                            rag_question = f"Corrige: {python_command}. Error: {error_message}"
                            res = rag_chain.invoke(rag_question)
                            correction_prompt = f"Reescribe el código en base a esto que ha devuelto el RAG:\n{res}\n\nError:\n{error_message}"
                        else:
                            correction_prompt = f"Indicaciones adicionales: {additional_guidance} Corrige este código:\n{python_command}\n\nError:\n{error_message}\n"
                        python_command = ffo(correction_prompt, df_columns, reformulation_prompt="{user_input}")
                        print("Comando corregido:", python_command, sep="\n", end="\n\n")
                        attempt += 1
                    else:
                        break

datagem(interfaz=True)


# In[ ]:




